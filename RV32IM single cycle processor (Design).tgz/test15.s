.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 57
    li x3, 8
    div x10, x2, x3
    ebreak
