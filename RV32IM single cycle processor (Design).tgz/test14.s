.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 57
    li x3, 8
    mulhu x10, x3, x2
    ebreak
