.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 60
    addi x3, zero, -1
    mulhu x10, x3, x2
    ebreak
