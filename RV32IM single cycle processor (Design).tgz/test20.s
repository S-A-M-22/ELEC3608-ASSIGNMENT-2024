.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, -127
    li x3, 8
    rem x10, x2, x3
    ebreak 
