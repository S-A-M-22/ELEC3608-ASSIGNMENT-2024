.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, -65
    li x3, -1
    mul x10, x3, x2
    ebreak
