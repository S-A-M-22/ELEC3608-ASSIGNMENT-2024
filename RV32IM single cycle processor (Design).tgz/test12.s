.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 4
    li x3, -44
    mulhsu x10, x3, x2
    ebreak
