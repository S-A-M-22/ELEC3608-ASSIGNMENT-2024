.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, -65
    addi x3, zero, -1
    mulh x10, x3, x2
    ebreak
