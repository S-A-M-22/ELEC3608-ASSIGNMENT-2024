.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, -63
    li x3, -1
    div x10, x2, x3
    ebreak
