.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, -36
    li x3, 7
    mulh x10, x2, x3
    ebreak
