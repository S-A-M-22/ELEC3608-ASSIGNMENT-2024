.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 64
    li x3, 8
    remu x10, x3, x2
    ebreak 
