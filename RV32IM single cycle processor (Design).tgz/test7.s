.section .text
.global main
.global _start
_start:
    addi x10, zero, 0
    li x2, 20
    li x3, 1024
    mul x10, x3, x2
    ebreak
